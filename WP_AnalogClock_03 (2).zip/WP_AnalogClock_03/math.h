﻿#pragma once

#define PI 3.141592f
#define RAD(x) PI/180.0f*(x)

