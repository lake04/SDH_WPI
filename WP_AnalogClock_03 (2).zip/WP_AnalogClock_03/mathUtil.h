﻿#pragma once

#define PI 3.141592f
#define RAD(x) ((x)*(PI/180.0f))
